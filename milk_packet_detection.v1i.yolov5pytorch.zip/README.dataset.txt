# milk_packet_detection > 2024-12-16 12:30pm
https://universe.roboflow.com/nano-cktse/milk_packet_detection

Provided by a Roboflow user
License: CC BY 4.0

